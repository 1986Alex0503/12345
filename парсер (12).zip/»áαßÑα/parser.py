import asyncio
from selenium import webdriver
from bs4 import BeautifulSoup
from tabulate import tabulate
from tqdm import tqdm
from loguru import logger
import re
from typing import List, Tuple, Dict, Any
from translator import translate_data
from google_sheets import save_to_google_sheet
import json

async def get_html_content(link_factory: str) -> str:
    """
    Получает HTML-контент страницы по указанной ссылке.

    Args:
        link_factory (str): Ссылка на страницу.

    Returns:
        str: HTML-контент страницы.
    """
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--window-size=1920x1080")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-software-rasterizer")
    driver = webdriver.Chrome(options=chrome_options)
    driver.minimize_window()
    driver.get(link_factory)
    await asyncio.sleep(0.2)
    html_content = driver.page_source
    driver.quit()
    return html_content


def parse_company_name_and_links(html_content: str) -> Tuple[str, List[str], List[str]]:
    """
    Парсит название компании и ссылки на продукты из HTML-контента.

    Args:
        html_content (str): HTML-контент страницы.

    Returns:
        tuple: Название компании, список ссылок на продукты, список названий подкатегорий.
    """
    soup = BeautifulSoup(html_content, 'html.parser')

    # Извлечение названия компании
    company_name = None
    header_info = soup.find('div', class_='header-profile-info')
    if header_info:
        name_tag = header_info.find('h1', class_='name')
        if name_tag:
            company_name = name_tag.text.strip()

    # Извлечение ссылок на продукты и названий подкатегорий
    product_links = []
    subcategory_names = []
    solution_carousel = soup.find('div', id='solutionCarousel')
    if solution_carousel:
        links = solution_carousel.find_all('a', href=True)
        for link in links:
            href = link['href']
            full_link = f"https://www.archiproducts.com{href}"
            product_links.append(full_link)

            # Извлечь имя подкатегории
            data_label = link.get('data-label')
            if data_label:
                subcategory_names.append(data_label)

    logger.info(f"Найдено {len(product_links)} коллекции")
    return company_name, product_links, subcategory_names


async def get_all_product_links(product_links: List[str]) -> List[str]:
    """
    Получает все ссылки на продукты из списка ссылок на подкатегории.

    Args:
        product_links (list): Список ссылок на подкатегории.

    Returns:
        list: Список всех ссылок на продукты.
    """
    all_product_link = []
    for product in product_links:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--window-size=1920x1080")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-software-rasterizer")
        driver = webdriver.Chrome(options=chrome_options)
        driver.minimize_window()
        driver.get(f'{product}')
        await asyncio.sleep(0.2)
        html_content = driver.page_source
        driver.quit()
        product_links = await parse_data(html_content)
        all_product_link.extend(product_links)

    logger.info(f'Всего товаров: {len(all_product_link)}')
    return all_product_link


async def parse_data(html_content: str) -> List[str]:
    """
    Парсит ссылки на продукты из HTML-контента.

    Args:
        html_content (str): HTML-контент страницы.

    Returns:
        list: Список ссылок на продукты.
    """
    soup = BeautifulSoup(html_content, 'html.parser')
    product_links = []
    search_items = soup.find_all('a', class_='_search-item-anchor')
    for item in search_items:
        product_link = item.get('href')
        full_product_link = f'https://www.archiproducts.com{product_link}'
        product_links.append(full_product_link)
    return product_links


def parse_dimensions(dimensions_str: str) -> Tuple[int, int, int]:
    """
    Парсит размеры из строки.

    Args:
        dimensions_str (str): Строка с размерами.

    Returns:
        tuple: Кортеж с размерами (длина, глубина, высота).
    """
    dimensions_str = dimensions_str.replace("Dimensions can be customized on request", "").strip()
    numbers = [int(num) for num in re.findall(r"\d+", dimensions_str)]
    separated_numbers = []
    for part in dimensions_str.split('/'):
        part_numbers = [int(num) for num in re.findall(r"\d+", part)]
        separated_numbers.extend(part_numbers)
    while len(separated_numbers) < 3:
        separated_numbers.append(0)
    return tuple(separated_numbers)


async def scrape_product_data(product_link: str, company_name: str, folder_ids) -> Dict[str, Any]:
    """
    Скрапит данные о продукте по указанной ссылке и переводит их на 5 языков.

    Args:
        product_link (str): Ссылка на продукт.
        company_name (str): Название компании.

    Returns:
        dict: Данные о продукте.
        :param product_link:
        :param company_name:
        :param folder_ids:
    """
    try:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--window-size=1920x1080")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-software-rasterizer")
        chrome_options.add_argument("--blink-settings=imagesEnabled=false")
        driver = webdriver.Chrome(options=chrome_options)
        driver.minimize_window()
        driver.get(product_link)
        await asyncio.sleep(0.1)
        html_content = driver.page_source
        driver.quit()

        soup = BeautifulSoup(html_content, 'html.parser')
        product_data = {}

        # Извлечение названия продукта
        try:
            product_name = soup.find('h2', class_='product-name').text.strip()
            product_data['name'] = product_name
        except Exception as e:
            product_data['name'] = ''

        # Извлечение описания продукта
        try:
            desc_container = soup.find('div', class_='product-desc-container')
            if desc_container:
                description_tags = desc_container.find_all('p')
                description_text = ''
                for tag in description_tags:
                    description_text += tag.get_text(strip=True) + '\n'
                product_data['description'] = description_text
            else:
                product_data['description'] = ''
        except Exception as e:
            product_data['description'] = ''

        # Извлечение изображений продукта
        try:
            image_tags = soup.find_all('img', class_='carousel-cell-image')
            image_urls = [img['content'] for img in image_tags if 'content' in img.attrs]
            product_data['Images'] = '\n'.join(image_urls)
        except Exception as e:
            product_data['Images'] = ''

        product_data['link_product'] = product_link

        # Извлечение размеров продукта
        try:
            dimensions = soup.find('div', class_='accordion-content')
            product_data['Length'] = ()
            product_data['Depth'] = ()
            product_data['Height'] = ()

            if dimensions:
                dimensions_text = dimensions.text.strip()
                dimensions_data = parse_dimensions(dimensions_text)
                for i in range(0, len(dimensions_data), 3):
                    product_data['Length'] += (dimensions_data[i],)
                    product_data['Depth'] += (dimensions_data[i + 1],)
                    product_data['Height'] += (dimensions_data[i + 2],)
                product_data['size'] = dimensions_text
        except Exception as e:
            product_data['size'] = ''

        # Извлечение коллекции продукта
        try:
            collection_tag = soup.find('h5', string=lambda text: text and 'Collection' in text)
            if collection_tag:
                collection = collection_tag.text.strip()
                product_data['Collections'] = collection
        except Exception as e:
            product_data['Collections'] = ''

        # Извлечение типа мебели
        try:
            type_tag = soup.find('div', class_='cell small-12 medium-9')
            if type_tag:
                furniture_type = type_tag.find('h2').text.strip()
                product_data['Furniture Types'] = furniture_type
        except Exception as e:
            product_data['Furniture Types'] = ''

        # Перевод данных на 5 языков
        headers = ["Название товара", "Описание", "Изображения", "Ссылка на товар", "Размер", "Длина", "Глубина",
                   "Высота",
                   "Диаметр", "Внутренняя длина", "Внутренняя ширина", "Внешняя длина", "Внешняя ширина", "Раскладка",
                   "Коллекции", "Предмет", "Типы мебели", "Категория", "Цвета", "Объем (куб)", "Стиль", "Материал",
                   "Отделка", "Файлы каталоги фабрики", "Файлы прайсы фабрики"]

        row = [product_data.get('name', ''), product_data.get('description', ''), product_data.get('Images', ''),
               product_data.get('link_product', ''),
               product_data.get('size', ''), product_data.get('Length', ''), product_data.get('Depth', ''),
               product_data.get('Height', ''),
               product_data.get('Diameter', ''), product_data.get('Inner Length', ''),
               product_data.get('Inner Width', ''),
               product_data.get('Outer Length', ''), product_data.get('Outer Width', ''),
               product_data.get('Layout', ''),
               product_data.get('Collections', ''), product_data.get('Item', ''),
               product_data.get('Furniture Types', ''),
               product_data.get('Category', ''), product_data.get('Colors', ''), product_data.get('Volume', ''),
               product_data.get('Style', ''),
               product_data.get('Material', ''), product_data.get('Finish', ''), product_data.get('Catalog Files', ''),
               product_data.get('Price Files', '')]

        table_data = [headers, row]

        # Перевод данных на 5 языков
        translated_data = translate_data(table_data)

        # Сохранение переведенных данных в соответствующие таблицы
        save_to_google_sheet(table_data, f"{company_name}_EN", "Английский", folder_ids)
        save_to_google_sheet(translated_data['ru'], f"{company_name}_RU", "Русский", folder_ids)
        save_to_google_sheet(translated_data['de'], f"{company_name}_DE", "Немецкий", folder_ids)
        save_to_google_sheet(translated_data['fr'], f"{company_name}_FR", "Французский", folder_ids)
        save_to_google_sheet(translated_data['it'], f"{company_name}_IT", "Итальянский", folder_ids)

        return product_data

    except Exception as e:
        logger.error(f"Ошибка скрапинга данных для продукта {product_link}: {e}")
        return {}


async def process_product_links(all_links_product: List[str], company_name: str, folder_ids) -> List[Dict[str, Any]]:
    """
    Обрабатывает все ссылки на продукты и скрапит данные о каждом продукте.

    Args:
        all_links_product (list): Список всех ссылок на продукты.
        company_name (str): Название компании.

    Returns:
        list: Список данных о всех продуктах.
    """
    all_product_data = []
    with tqdm(total=len(all_links_product), ncols=130, desc="Прогресс скрапинга", unit="ссылка",
              bar_format="{l_bar}{bar}{r_bar}", colour='#00ff00', leave=True) as pbar:
        for product_link in all_links_product:
            product_data = await scrape_product_data(product_link, company_name, folder_ids)
            all_product_data.append(product_data)
            pbar.update(1)
    return all_product_data


async def main(factory_link, folder_ids):
    """
    Основная функция для выполнения скрапинга, перевода и сохранения данных.
    """
    print('Собираю данные...')
    html_content = await get_html_content(factory_link)
    company_name, product_links, subcategory_names = parse_company_name_and_links(html_content)
    if not company_name:
        company_name = 'default_sheet_name'  # используем значение по умолчанию, если имя не найдено

    product = await get_all_product_links(product_links)
    all_product_data = await process_product_links(product, company_name, folder_ids)

    # Определение заголовков таблицы
    headers = ["Название товара", "Описание", "Изображения", "Ссылка на товар", "Размер", "Длина", "Глубина", "Высота",
               "Диаметр", "Внутренняя длина", "Внутренняя ширина", "Внешняя длина", "Внешняя ширина", "Раскладка",
               "Коллекции", "Предмет", "Типы мебели", "Категория", "Цвета", "Объем (куб)", "Стиль", "Материал",
               "Отделка",
               "Файлы каталоги фабрики", "Файлы прайсы фабрики"]

    # Формирование данных таблицы
    table_data = [headers]
    for product_data in all_product_data:
        name = product_data.get('name', '')
        description = product_data.get('description', '')
        size = product_data.get('size', '')
        length = product_data.get('Length', '')
        depth = product_data.get('Depth', '')
        height = product_data.get('Height', '')
        link_product = product_data.get('link_product', '')
        images = product_data.get('Images', '')
        diameter = product_data.get('Diameter', '')
        inner_length = product_data.get('Inner Length', '')
        inner_width = product_data.get('Inner Width', '')
        outer_length = product_data.get('Outer Length', '')
        outer_width = product_data.get('Width', '')
        layout = product_data.get('Layout', '')
        collections = product_data.get('Collections', '')
        item = product_data.get('Item', '')
        furniture_types = product_data.get('Furniture Types', '')
        category = product_data.get('Category', '')
        colors = product_data.get('Colors', '')
        volume = product_data.get('Volume', '')
        style = product_data.get('Style', '')
        material = product_data.get('Material', '')
        finish = product_data.get('Finish', '')
        catalog_files = product_data.get('Catalog Files', '')
        price_files = product_data.get('Price Files', '')

        row = [name, description, images, link_product, size, length, depth, height, diameter,
               inner_length, inner_width, outer_length, outer_width, layout, collections, item, furniture_types,
               category, colors, volume, style, material, finish, catalog_files, price_files]
        table_data.append(row)

    # Вывод данных таблицы в консоль
    # print(tabulate(table_data, headers="firstrow", tablefmt="fancy_grid"))


if __name__ == '__main__':
    with open('folder_ids.json', 'r', encoding='utf-8') as f:
        folder_ids = json.load(f)
    asyncio.run(main('https://www.archiproducts.com/en/arredoclassic', folder_ids))
