import json
import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from loguru import logger

# Переменные для аутентификации
credentials_file = "tutorial.json"
scopes = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]


def delete_created_sheets():
    """
    Ищет и удаляет все Google Таблицы, созданные программой.
    """
    try:
        # Аутентификация в Google API
        creds = Credentials.from_service_account_file(credentials_file, scopes=scopes)
        drive_service = build('drive', 'v3', credentials=creds)

        # Поиск всех таблиц, созданных программой
        query = "mimeType='application/vnd.google-apps.spreadsheet'"
        results = drive_service.files().list(q=query, fields="files(id, name)").execute()
        items = results.get('files', [])

        if not items:
            logger.info("Не найдено ни одной таблицы для удаления.")
            return

        # Удаление найденных таблиц
        for item in items:
            file_id = item['id']
            file_name = item['name']
            drive_service.files().delete(fileId=file_id).execute()
            logger.info(f"Таблица '{file_name}' (ID: {file_id}) успешно удалена.")

    except Exception as e:
        logger.error(f"Ошибка при удалении таблиц: {e}")


if __name__ == "__main__":
    delete_created_sheets()
