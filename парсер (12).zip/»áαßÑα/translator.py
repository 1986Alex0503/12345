from googletrans import Translator
import re
from tabulate import tabulate
import time
from loguru import logger


def translate_data(data, src_lang='en', dest_langs=['ru', 'de', 'fr', 'it'], max_retries=2):
    """
    Переводит данные на указанные языки.

    Args:
        data (list): Данные для перевода.
        src_lang (str): Исходный язык данных.
        dest_langs (list): Список языков для перевода.
        max_retries (int): Максимальное количество попыток перевода в случае ошибки.

    Returns:
        dict: Переведенные данные для каждого языка.
    """
    translator = Translator()
    translated_data = {lang: [] for lang in dest_langs}

    headers = data[0]
    url_pattern = re.compile(r'http[s]?://')

    for row in data[1:]:
        for lang in dest_langs:
            translated_row = []
            for cell in row:
                if cell is None or isinstance(cell, (tuple, list)) or url_pattern.match(str(cell)):
                    # Пропускаем значения None, значения типа tuple или list, и URL-адреса
                    translated_row.append(cell)
                    continue
                for attempt in range(max_retries):
                    try:
                        if cell.strip() == '':
                            translated_text = cell
                        else:
                            translated_text = translator.translate(str(cell), src=src_lang, dest=lang).text
                        break  # Успешный перевод, выходим из цикла попыток
                    except Exception as e:
                        # logger.error(f"Error translating cell '{cell}' to {lang}: {e}")
                        if attempt < max_retries - 1:
                            # logger.error(f"Retrying... ({attempt + 1}/{max_retries})")
                            time.sleep(2)  # Ждем перед повторной попыткой
                        else:
                            # logger.error(f"Failed to translate cell '{cell}' to {lang} after {max_retries} attempts.")
                            translated_text = cell  # Добавьте исходный текст в случае ошибки
                translated_row.append(translated_text)
            translated_data[lang].append(translated_row)

    for lang in dest_langs:
        translated_data[lang].insert(0, headers)

    return translated_data


if __name__ == "__main__":
    # Пример использования функции и форматирования вывода
    data = [
        ["Header1", "Header2"],
        ["Hello", "World"],
        ["https://example.com", "Test"],
        ["Melodia", "Leonardo Collection by Arredoclassic"]
    ]

    translated_data = translate_data(data)

    for lang, translated in translated_data.items():
        print(f"\nTranslated data to {lang}:")
        print(tabulate(translated, headers="firstrow", tablefmt="grid"))