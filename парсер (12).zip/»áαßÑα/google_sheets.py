import json
import gspread
from google.oauth2.service_account import Credentials
from loguru import logger
from googleapiclient.discovery import build

# Переменные для аутентификации и идентификации таблицы
credentials_file = "tutorial.json"
scopes = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]


def save_to_google_sheet(data, name_sheet, language, folder_ids):
    """
    Сохраняет данные в существующую Google Таблицу с указанным именем в указанную папку.

    Args:
        data (list): Данные для сохранения.
        name_sheet (str): Имя листа и таблицы для сохранения.
        language (str): Имя языка для определения идентификатора папки.

    Returns:
        bool: True, если данные успешно сохранены, в противном случае False.
    """
    try:
        # Получение идентификатора папки по имени языка
        folder_id = folder_ids.get(language)
        if not folder_id:
            raise ValueError(f"Идентификатор папки для языка '{language}' не найден.")

        # Аутентификация в Google Таблице
        creds = Credentials.from_service_account_file(credentials_file, scopes=scopes)
        client = gspread.authorize(creds)

        # Проверка, существует ли таблица с указанным именем
        try:
            workbook = client.open(name_sheet)
        except gspread.SpreadsheetNotFound:
            # Создание новой таблицы с указанным именем, если она не существует
            workbook = client.create(name_sheet)

            # Перемещение таблицы в указанную папку
            drive_service = build('drive', 'v3', credentials=creds)
            file_id = workbook.id
            drive_service.files().update(
                fileId=file_id,
                addParents=folder_id,
                removeParents='root',
                fields='id, parents'
            ).execute()

        # Открытие существующей таблицы
        sheet = workbook.sheet1
        sheet.update_title(name_sheet)

        # Преобразование числовых значений в строки перед записью в таблицу
        data_as_strings = [[str(value) for value in row] for row in data]

        # Запись данных в таблицу, начиная с первой пустой строки
        for row in data_as_strings:
            sheet.append_row(row)
        # logger.info(
        #     f"Данные успешно сохранены в Google Таблицу '{name_sheet}'")
        return True
    except Exception as e:
        logger.error(f"Ошибка сохранения данных в Google Таблицу: {e}")
        return False


if __name__ == "__main__":
    data = [['Название товара', 'Описание', 'Изображения', 'Ссылка на товар', 'Размер', 'Длина', 'Глубина', 'Высота',
             'Диаметр', 'Внутренняя длина', 'Внутренняя ширина', 'Внешняя длина', 'Внешняя ширина', 'Раскладка',
             'Коллекции', 'Предмет', 'Типы мебели', 'Категория', 'Цвета', 'Объем (куб)', 'Стиль', 'Материал', 'Отделка',
             'Файлы каталоги фабрики', 'Файлы прайсы фабрики'],
            ['TWICE By Novamobili', 'TWICE\xa0is a bed ...',
             'https://img.edilportale.com/product-thumbs/b_TWICE-Novamobili-562329-rel8a545451.jpg \nhttps://img.edilportale.com/product-thumbs/b_TWICE-Novamobili-562329-reld75d13e1.jpg \nhttps://img.edilportale.com/product-thumbs/b_TWICE-Novamobili-562329-rele1581b96.jpg \nhttps://img.edilportale.com/product-thumbs/b_TWICE-Novamobili-562329-rel620439ea.jpg \nhttps://img.edilportale.com/product-thumbs/b_TWICE-Novamobili-562329-relb2836992.jpg',
             'https://www.archiproducts.com/en/products/novamobili/wooden-double-bed-with-upholstered-headboard-twice_562329',
             'Width: 197 / 197 cmDepth: 224 / 234 cmHeight: 106 / 106 cm',
             '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
             '', '', '', '', '', '']]

    sheet_name = '1206'
    save_to_google_sheet(data, sheet_name, "Русский")
