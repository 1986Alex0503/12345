import parser
import asyncio
from loguru import logger
import os
import json
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from time import sleep
import re


# Настройка логирования
logger.add("file.log", format="{time} {level} {message}", level="DEBUG", rotation="50 MB", compression="zip")

# Переменные для аутентификации
credentials_file = "tutorial.json"
scopes = ["https://www.googleapis.com/auth/drive"]


# parent_folder_id = "1-5FjmrbBG2ZdoxPh3NDEQEmUsCFzKlco"  # Идентификатор вашей папки


def create_folders_and_save_ids(parent_folder_id):
    """
    Создает папки в указанной папке Google Drive и сохраняет их идентификаторы в JSON файл.
    """
    try:
        # Аутентификация в Google Drive
        creds = Credentials.from_service_account_file(credentials_file, scopes=scopes)
        drive_service = build('drive', 'v3', credentials=creds)

        # Имена папок для создания
        folder_names = ["Русский", "Немецкий", "Французский", "Итальянский", "Английский"]
        folder_ids = {}

        # Создание папок и получение их идентификаторов
        for folder_name in folder_names:
            file_metadata = {
                'name': folder_name,
                'mimeType': 'application/vnd.google-apps.folder',
                'parents': [parent_folder_id]  # Указывает, что папка должна быть создана внутри указанной папки
            }
            folder = drive_service.files().create(body=file_metadata, fields='id').execute()
            folder_ids[folder_name] = folder.get('id')
            logger.info(f"Создана папка '{folder_name}'")

        # Сохранение идентификаторов папок в JSON файл
        with open('folder_ids.json', 'w', encoding='utf-8') as f:
            json.dump(folder_ids, f, ensure_ascii=False, indent=4)

        logger.info("Идентификаторы папок успешно сохранены в 'folder_ids.json'")
    except Exception as e:
        logger.error(f"Ошибка при создании папок или сохранении идентификаторов: {e}")


def checking_file():
    """
    Проверка наличия файла folder_ids.json

    :return:
    """
    if not os.path.exists('folder_ids.json'):
        print("Создайте папку с любым именем на https://drive.google.com/drive/home, \n"
              "откройте к ней доступ всем, разрешите чтение и редактирование и пришлите ее ссылку")
        url = input('Введите ссылку на свою папку: ')
        # Регулярное выражение для извлечения идентификатора папки
        pattern = r"folders/([a-zA-Z0-9_-]+)"
        match = re.search(pattern, url)
        if match:
            folder_id = match.group(1)
            print("Идентификатор папки:", folder_id)
        else:
            print("Ссылка не корректна")
            return False
        create_folders_and_save_ids(folder_id)
        sleep(2)
        return True
    else:
        return True


if __name__ == '__main__':
    if checking_file():
        with open('folder_ids.json', 'r', encoding='utf-8') as f:
            folder_ids = json.load(f)
        link = input('Напиши ссылку на фабрику товаров: ')
        asyncio.run(parser.main(link, folder_ids))